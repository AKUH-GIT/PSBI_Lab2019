
use psbi_lab


alter table form1 add AS2_Q7_2a varchar(50)
alter table sample_result alter column CS_09_a varchar(20)
alter table sample_result alter column LA_17 varchar(max)
alter table sample_result alter column LA_18 varchar(max)
alter table sample_result alter column LA_19 varchar(max)




